
UserName = "mbaital" 'InputBox("Enter the user name for QC Login", "QC UserName")
Password = "Welcome2ibm8*" 'InputBox("Enter the password for QC Login", "QC Password")
strExecFlag = "P" 'InputBox("Enter the option for test execution" & vbcrlf & "Valid Values - P, A,F" & vbcrlf & "A: Run All test Scripts"& vbcrlf & "F: ExecuTe script not passed Only"& vbcrlf & "P: Execute Passed Test Scripts","Test Execution Option")
'Return the TDConnection object.
 
Set QCConnection = CreateObject("TDApiOle80.TDConnection")
QCConnection.InitConnectionEx "https://hpalm-qc.bmogc.net:8443/qcbin/"
QCConnection.login UserName, Password

Domain = "AML"
Project = "PR009103_US_20_21_Rel_1_TPT"
QCConnection.Connect Domain, Project  
wait(5)
'Dim BugFact As BugFactory
'    Dim BugFilter As TDFilter
'    Dim bugList As List
'    Dim theBug As Bug
'    Dim i%, msg$
    
' Get the bug factory filter.
    'tdc is the global TDConnection object.
    Set BugFact = QCConnection.BugFactory
    Set BugFilter = BugFact.Filter
    
' Set the filter values.
    BugFilter.Filter("BG_STATUS") = "Closed"
    BugFilter.order("BG_PRIORITY") = 1
    MsgBox BugFilter.Text

'Create a list of defects from the filter
' and show a few of them.
    Set bugList = BugFilter.NewList
    msg = "Number of defects = " & bugList.Count & Chr(13)
    For Each theBug In bugList
       msg = msg & theBug.ID & ", " & theBug.Summary & ", " _
        & theBug.Status & ", " & theBug.Priority & Chr(13)
       i = i + 1
       If i > 10 Then Exit For
    Next
    MsgBox msg