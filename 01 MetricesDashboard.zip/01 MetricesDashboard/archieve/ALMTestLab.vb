GetScript()

Public Sub GetScript()
	Dim mylist
	Dim test_m
	test_m = "NetReveal_Regression_Execution_Feb-2018"
	Set mylist = GetTestSet(test_m)

	For Each Test In mylist
		If (Not (Test.LastRun Is Nothing)) Then
			MsgBox "Test Case ID: " & Test.ID & ", Test Case Name: " & Test.Name & ", Result: " & Test.LastRun.Status
		Else
			MsgBox "Test Case ID: " & Test.ID & ", Test Case Name: " & Test.Name & ", Result: No_Run"
		End If
	Next
End Sub


Function GetTestSet(SetFilter)

	Dim testSetFactory
	Dim testfactory1
	Dim testfactory
	Dim filters
	Dim testSetFilter
	Dim testFilter
	Dim lists
	Dim setList
	Dim testList
	Dim treeMgr
	Dim subjRoot
	Dim childNode
	Dim tstTree
	Dim tstFactory
	Dim rootName
	Dim treesList
	Dim tsetList
	Dim txtTestSet
	Dim txtfolderpath


	Dim QCConnection
	
	UserName = "mbaital" 'InputBox("Enter the user name for QC Login", "QC UserName")
	Password = "Welcome2ibm8*" 'InputBox("Enter the password for QC Login", "QC Password")

	Set QCConnection= CreateObject("TDApiOle80.TDConnection")
	QCConnection.InitConnectionEx "https://hpalm-qc.bmogc.net:8443/qcbin/"
	QCConnection.Login UserName, Password

	Domain = "AML"
	Project = "PR009103_US_20_21_Rel_1_TPT"
	QCConnection.Connect Domain, Project 
	Wait(5)

	Set treeMgr = QCConnection.TestSetTreeManager

	Set tstTree = treeMgr.NodeByPath("Root\US AML Regression Execution\Test Run")

	Set testSetFactory = tstTree.testSetFactory
	Set testSetFilter = testSetFactory.Filter

	Set testfactory = QCConnection.testFactory
	Set testFilter = testfactory.Filter

	If SetFilter <> "" Then
		testSetFilter.Filter("CY_CYCLE") =  Chr(34) & setFilter & Chr(34)
	End If

	Set testList = testSetFactory.NewList(testSetFilter.Text)

	testFilter.SetXFilter "TEST-TESTSET", True, testSetFilter.Text
	Set testList = testfactory.NewList(testFilter.Text)

	Set GetTestSet = testList

End Function